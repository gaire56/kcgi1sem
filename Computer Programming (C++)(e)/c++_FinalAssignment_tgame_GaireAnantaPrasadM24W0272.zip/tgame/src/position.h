#pragma once

class Position
{
public:
    Position(int row, int column); // Constructor declaration
    int row;    // Public member variable for row
    int column; // Public member variable for column
};
